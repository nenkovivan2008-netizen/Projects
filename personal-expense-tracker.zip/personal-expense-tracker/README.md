# Personal Expense Tracker

A learning project built in Python: record expenses, assign categories, and calculate monthly spending. Step 1 uses only the Python standard library and a terminal menu.

## Run on your Mac

1. Extract the ZIP and move the `personal-expense-tracker` folder to Downloads if needed.
2. Open Terminal and run:

```bash
cd ~/Downloads/personal-expense-tracker
python3 --version
python3 expense_tracker.py
```

Requires Python 3.8 or newer. No packages to install. If the folder is elsewhere, type `cd `, drag the folder into Terminal, and press Enter. If `python3` is unavailable, finish setting up Python before running this project.

**Step 1 limitation:** data lives in memory and disappears on exit. This version records positive expenses in euros, not income or refunds. It does not connect to your bank.

## Try it

Add these fictional expenses using menu option 1:

| Date | Euros | Category | Description |
| --- | ---: | --- | --- |
| 2026-10-08 | 12.50 | Food | Lunch |
| 2026-10-09 | 2.20 | Transport | Metro |
| 2026-10-10 | 7.30 | Food | Groceries |
| 2026-11-01 | 9.00 | Study | Notebook |

Choose option 3 and enter `2026-10`. Expected: total **€22.00**, Food **€19.80**, Transport **€2.20**. The November expense must not appear in October's totals. An empty month returns zero.

Try `hello`, `0`, `-5`, or `12.345` as an amount. The program should explain the problem and ask again. Both `12.50` and `12,50` work; do not use thousands separators. Try an impossible date such as `2026-02-30` and an invalid category number too.

## Understand the code

Read `main()` first, then follow the function calls for each menu option.

### 1. One list holds many dictionaries

`transactions = []` starts an empty list. Each expense is a dictionary with named fields:

```python
{
    "date": "2026-10-08",
    "amount_cents": 1250,
    "category": "Food",
    "description": "Lunch",
}
```

`transaction["category"]` retrieves `"Food"`. `transactions.append(transaction)` adds the new dictionary to the list. The function receives the same list object used by `main()`, so appending changes that list without needing to return it.

### 2. The menu repeats

`while True` repeats until a `break` statement ends the loop. `input()` returns text, so the menu compares with `"1"`, not the integer `1`. The `if`/`elif` branches choose which function runs. `.strip()` removes surrounding spaces.

### 3. Validate before saving

`date.fromisoformat()` checks whether the date exists. `try` runs code that might fail; `except ValueError` handles invalid input and keeps the program running. Each input loop ends only after valid input.

`enumerate(CATEGORIES, start=1)` produces a number and category for each menu entry. Lists start at index 0, so category choice 1 becomes `CATEGORIES[0]` through `int(choice) - 1`.

### 4. Money uses whole cents

Binary floating-point numbers cannot represent every decimal fraction exactly. `Decimal` reads a typed decimal amount accurately. After validation, `int(amount * 100)` stores euros as whole cents. Adding 1250 and 220 gives exactly 1470 cents.

`format_money()` uses integer division (`//`) for whole euros and remainder (`%`) for leftover cents. `:02d` prints cents using two digits, so five cents displays as `€0.05`. The one-million-euro input ceiling is a deliberate validation rule for this small personal project.

### 5. Filter a month and accumulate totals

`"2026-10-08"[:7]` produces `"2026-10"`: slicing selects the first seven characters. Because we validate and store dates in one consistent format, comparing this slice with the chosen month works reliably and distinguishes different years.

```python
total += amount
category_totals[transaction["category"]] += amount
```

The first line increases total monthly spending. The second increases only the matching category's total. `+=` means "add to the existing value".

`{category: 0 for category in CATEGORIES}` creates a dictionary with a starting total of zero for every category. It is a shorter way to write a loop that assigns `category_totals[category] = 0`.

`calculate_monthly_totals()` returns two values, unpacked into `total, category_totals`. Keeping calculations separate from `input()` and `print()` makes them easier to check and reuse when we add storage or charts.

### 6. The entry point

`if __name__ == "__main__":` runs the menu when this file is launched directly. Importing its functions from another Python file does not automatically launch the menu.

## First Git commit

From inside this project folder:

```bash
git init -b main
git status
git add expense_tracker.py README.md .gitignore
git commit -m "Add basic expense tracker with monthly category totals"
git log --oneline
```

`git init` creates a repository in this folder. `git add` stages the selected files. `git commit` saves a local snapshot; it does not upload anything to GitHub. If Git requests your identity, set your own name and email using `git config user.name "Your Name"` and `git config user.email "your-email@example.com"`, then retry the commit.

When ready to publish, create an empty GitHub repository named `personal-expense-tracker`. Leave its README, licence and .gitignore initialisation options unchecked because the local project already has files. Use the repository URL GitHub gives you:

```bash
git remote add origin https://github.com/YOUR_USERNAME/personal-expense-tracker.git
git push -u origin main
```

Replace `YOUR_USERNAME` before running the command. Authentication may require GitHub's sign-in setup. The included `.gitignore` excludes future databases and the `data/` folder; put personal CSV imports inside `data/`.

## Learning roadmap

Implement one stage at a time and commit each working stage:

1. **Current:** in-memory expense entry, fixed categories, transaction list, monthly totals, input validation.
2. **SQLite:** persist transactions, create a table, insert with SQL parameters, query saved records. Check that data survives restarting the app.
3. **CSV import:** agree on columns, validate rows, show imported/rejected counts, and decide how repeated imports should be handled. Use fictional sample data in the repository.
4. **Spending charts:** draw category spending and monthly trends with Matplotlib, using the same stored data as the totals.
5. **Budget alerts:** set monthly category limits, compare actual expenses with each limit, and show terminal warnings at 80% and 100%. These are app warnings, not background notifications.

SQLite and CSV support come with Python. Matplotlib will introduce our first external dependency and a virtual environment. Later steps are planned, not implemented in this version.

## Explain it in an interview

Be able to explain the data structure, input validation, money representation, monthly filtering, and the current lack of persistence. Understand these before claiming the project on your CV. Describe your own contributions accurately, including how you used assistance and what you tested or extended yourself.

Practice questions:

- Why is each transaction a dictionary inside a list?
- Why store 1250 cents rather than the float 12.50?
- How do we exclude November's expenses from October's total?
- Why does appending inside a function change the original list?
- What changes when the program exits, and how will SQLite fix that?

Small exercise: add `Health` to `CATEGORIES`, record a fictional pharmacy expense, and check that the new category appears in the monthly totals. Explain why no new `if` statement was needed.
